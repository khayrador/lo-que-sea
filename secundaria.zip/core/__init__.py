# Core modules for Jarvis Assistant
